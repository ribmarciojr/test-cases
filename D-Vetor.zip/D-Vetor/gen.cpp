// #include <bits/stdc++.h>
#include <algorithm> 
#include <random>
#include <iostream>
#include <cassert>
#include <set>
using namespace std;

namespace {
  static std::mt19937 &random_engine() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    return gen;
  }

  template <typename T>
  static T rand_int(const T &a, const T &b) {
    std::uniform_int_distribution<T> dis(a, b);
    return dis(random_engine());
  }

  template <typename Container>
  static auto rand_elem(const Container &container) ->
      typename Container::value_type {
    assert(container.size() > 0);
    return container[rand_int(0, (int)container.size() - 1)];
  }

  static string rand_string(const string &charset, int size) {
    string s(size, '0');
    for (int i = 0; i < size; ++i) s[i] = rand_elem(charset);
    return s;
  }
}  // namespace

signed main(int argc, char *argv[]) {
  const bool is_big_input = (argc > 1);
  const int n = is_big_input ? 1000 : rand_int(1, 1000);
  
  int seats_qtd = rand_int(1, 48);
  cout << seats_qtd << endl;
  
  vector<int> available_seats;
  for(int i = 0; i < seats_qtd; i++){
    available_seats.push_back(rand_int(1, 48));
  }

  sort(available_seats.begin(), available_seats.end());
  
    set<int> s( available_seats.begin(), available_seats.end());
    available_seats.assign( s.begin(), s.end() );


    for (auto it = s.begin(); it != s.end(); ++it) {
        std::cout << *it << " ";
    }
    cout << "\n";

    cout << rand_string("CJ", 1) << " ";
    cout << rand_string("ED", 1) << " ";
    cout << rand_string("TF", 1) << " ";
}
