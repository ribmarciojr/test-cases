#include <iostream>
#include <vector>
#include <string>

int main(){
    int seats_qtd;
    std::vector<int> seats;
    std::vector<std::string > preferences;

    std::cin >> seats_qtd;

    for(int i = 0; i < seats_qtd; i++){
        int position;
    
        std::cin >> position;
        seats.push_back(position);
    }

    for(int i = 0; i < 3; i++){
        std::string preference;
        std::cin >> preference;

        preferences.push_back(preference);
    }

    std::vector<int> valid_seats = {};

    for(int i = 0; i < seats_qtd; i++){
        int number = seats[i];
        int quality = 0;

        int isWindowSeat = number % 2;
        if(isWindowSeat && preferences[0] == "J"){
            quality++;
        }

        if(!isWindowSeat && preferences[0] == "C"){
            quality++;
        }
        
        int isRightSide;
        if(isWindowSeat){
            isRightSide = (bool) !((number + 1) % 4);
        } else {
            isRightSide = (bool) !((number) % 4);
        }

        if(isRightSide && preferences[1] == "D"){
            quality++;
        }

        if(!isRightSide && preferences[1] == "E"){
            quality++;
        }

        int isFrontSeat = number <= 24;
        if(isFrontSeat && preferences[2] == "F"){
            quality++;
        }
        if(!isFrontSeat && preferences[2] == "T"){
            quality++;
        }

        if(quality == 3){
            valid_seats.push_back(number);
        }
    }

    if(valid_seats.size()){
        for(int i = 0; i < valid_seats.size(); i++){
            std::cout << valid_seats[i] << " ";
        }
    } else {
        std::cout << "Procure outro onibus" << std::endl;
    }
}