#include <bits/stdc++.h>
#include <random>

using namespace std;

namespace {
  static std::mt19937 &random_engine() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    return gen;
  }

  template <typename T>
  static T rand_int(const T &a, const T &b) {
    std::uniform_int_distribution<T> dis(a, b);
    return dis(random_engine());
  }

  template <typename Container>
  static auto rand_elem(const Container &container) ->
      typename Container::value_type {
    assert(container.size() > 0);
    return container[rand_int(0, (int)container.size() - 1)];
  }

  static string rand_string(const string &charset, int size) {
    string s(size, '0');
    for (int i = 0; i < size; ++i) s[i] = rand_elem(charset);
    return s;
  }
  
  template <typename D>
  static D rand_double(const D &a, const D &b){
    uniform_real_distribution<D> unifd(a, std::nextafter(b, std::numeric_limits<D>::max()));
    return unifd(random_engine());
  }
}  // namespace

signed main(int argc, char *argv[]) {
  const bool is_big_input = (argc > 1);
  const int n = is_big_input ? 1000 : rand_int(1, 1000);
  
  int N = rand_int(1, 1000);
  cout << N << "\n";

  for(int i = 0; i < N; i++){
    cout << rand_int(1, 10000) << " ";
  }
  cout << "\n";

  int M = rand_int(1, 1000);
  cout << M << "\n";

  for(int i = 0; i < M; i++){
    cout << rand_int(1, 10000) << " " << rand_int(1, 10000) << "\n";
  }

    
}
