#include <iostream>
#include <vector>
#include <algorithm>

// Se o iterador mínimo for igual o iterador.end(), a lista não possui tiras que atendem o requisito(min, max)
// min <= max

//Corner test:
// 7
// min = 1
// max = 5 


int main() {
    int N;
    std::cin >> N;

    std::vector<int> comprimentos(N);
    for (int i = 0; i < N; ++i) {
        std::cin >> comprimentos[i];
    }

    sort(comprimentos.begin(), comprimentos.end());

    int M;
    std::cin >> M;

    for(int i = 0; i < M; i++){
        int min_value, max_value;
        int isEmpty{1};
        std::cin >> min_value >> max_value;

        auto min = std::lower_bound(comprimentos.begin(), comprimentos.end(), min_value);
        auto max = std::upper_bound(comprimentos.begin(), comprimentos.end(), max_value);

        while (min < max)
        {
            std::cout << *min << " ";
            isEmpty = 0;
            min++;
        }
        
        if(isEmpty){
            std::cout << 0;
        }

        std::cout << "\n";
    }

    return 0;
}