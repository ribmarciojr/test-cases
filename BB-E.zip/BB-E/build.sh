#!/bin/bash
set -e

#../compile-statement.sh statement.md
rm -rf tests
mkdir -p tests/main
g++ -std=c++11 gen.cpp -O2 -o /tmp/gen
g++ -std=c++11 sol.cpp -O2 -o /tmp/sol

# Generate Tests
echo "Generating samples..."
printf "5
5 3 6 2 3
1
3 5
" > "tests/main/001.in"

printf "12
1 2 3 1 3 2 1 4 2 3 4 4
2
2 4
1 1
" > "tests/main/002.in"

echo "Generating corner-cases tests..."
printf "1\n10\n0 0" > "tests/main/004.in"

echo "Generating small tests..."
for i in {003..019}; do
    echo "Generating $i..."
    /tmp/gen > "tests/main/$i.in"
done
echo "Generating big tests..."
for i in {020..020}; do
    echo "Generating $i..."
    /tmp/gen big > "tests/main/$i.in"
done

# Solve Tests
for i in {001..020}; do
    echo "Solving $i..."
    /tmp/sol < "tests/main/$i.in" > "tests/main/$i.out"
done
