#include <iostream>
#include <vector>

// A matrix deve obter soma de linhas e colunas iguais
int main(){
    int n, m;
    std::vector<std::vector<int>> matrix;

    std::cin >> n >> m;
    //Recebe a matrix de input
    for(int i = 0; i < n; i++){
        std::vector<int> row;
        for(int j = 0; j < m; j++){
            int value;
            std::cin >> value;
            row.push_back(value);
        }
        matrix.push_back(row);
    };
    int especial{1};
    int firstLine{0};
    //Calcula a soma da primeira linha
    for(int j = 0; j < m; j++){
        firstLine += matrix[0][j];
    }
    
    for(int i = 1; i < n; i++){
        int sum{0};
        //Calcula a soma das demais linhas
        for(int j = 0; j < m; j++){
            sum += matrix[i][j];
        }
        //Se existe a soma de uma linha, tal que essa soma é diferente da soma da primeira linha, a matrix não é especial
        if(sum != firstLine){
            especial = 0;
        }
    }

    for(int i = 0; i < m; i++){
        int sum{0};
        //Calcula a soma das colunas
        for(int j = 0; j < n; j++){
            sum += matrix[j][i];
        }
        //Se existe a soma de uma coluna, tal que essa soma é diferente da soma da primeira linha, a matrix não é especial 
        if(sum != firstLine){
            especial = 0;
        }
    }

    if(especial){
        std::cout << "Sim" << std::endl;
    } else {
        std::cout << "Nao" << std::endl;
    }
}