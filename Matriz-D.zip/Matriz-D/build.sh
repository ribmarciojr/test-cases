#!/bin/bash
set -e

#../compile-statement.sh statement.md
rm -rf tests
mkdir -p tests/main
g++ -std=c++11 gen.cpp -O2 -o /tmp/gen
g++ -std=c++11 sol.cpp -O2 -o /tmp/sol

# Generate Tests
echo "Generating samples..."
printf "3 3\n2 7 6\n9 5 1\n4 3 8" > "tests/main/001.in"
printf "2 2\n1 2\n3 4" > "tests/main/002.in"

# echo "Generating corner-cases tests..."
# printf "1\n10\n0 0" > "tests/main/004.in"

echo "Generating small tests..."
for i in {003..017}; do
    echo "Generating $i..."
    /tmp/gen > "tests/main/$i.in"
done
echo "Generating big tests..."
for i in {018..020}; do
    echo "Generating $i..."
    /tmp/gen big > "tests/main/$i.in"
done

# Solve Tests
for i in {001..020}; do
    echo "Solving $i..."
    /tmp/sol < "tests/main/$i.in" > "tests/main/$i.out"
done
